# Credit Rating & Loan Eligibility System

A three-file desktop application built with Python, Tkinter, SQLite, and pandas. It manages applicant profiles, imports periodic financial updates, calculates credit scores, and evaluates loan eligibility.

## Submission Layout

```text
credit_rating_system/
├── main.py              # Application, database helpers, scoring, CSV import, and Tkinter UI
├── mock_generation.py   # Deterministic sample database and update-file generator
├── README.md            # This documentation
└── data/                # Generated runtime data
```

The application uses only the `credit_rating_system/data/` directory for its runtime database, credentials, and update files.

## Requirements and Installation

- Python 3.8 or newer
- Tkinter, normally included with standard Windows Python installations
- pandas

Install pandas from PowerShell:

```powershell
python -m pip install pandas
```

## Running the Application

Run these commands from the parent project directory:

```powershell
python credit_rating_system\main.py
```

The first run creates the SQLite schema, generates 50 sample users, creates January financial records, writes February and March CSV templates, and generates missing user passwords.

To generate only the sample data without opening the GUI:

```powershell
python credit_rating_system\mock_generation.py
```

The mock generator uses a fixed random seed, so a clean generation produces the same dataset every time. It does not duplicate users when the database is already initialized.

## Default Credentials

Administrator:

- Username: `admin`
- Password: `password`

Generated user passwords use the lowercase `namesurname123` format, for example `arjunsharma123`. They are written to `credit_rating_system/data/user_credentials.csv`.

## Database Schema

### `users`

Stores applicant identity and login information:

- `user_id`: Unique identifier.
- `first_name`, `last_name`: Applicant name.
- `email`: Unique email used for login and CSV matching.
- `date_of_birth`: Applicant date of birth.
- `employment_status`: `Employed`, `Self-Employed`, or `Unemployed`.
- `password_hash`: PBKDF2-derived password hash.

### `admins`

Stores administrator usernames and PBKDF2-derived password hashes.

### `financial_records`

Stores historical monthly financial snapshots:

- `record_date`: Date represented by the record.
- `monthly_income`: Monthly income.
- `existing_loan_emi`: Existing monthly loan payment.
- `credit_card_utilization`: Utilization ratio from `0.00` to `1.00`.
- `missed_payments_count`: Missed-payment count for that period.
- `employment_tenure_months`: Current-employer tenure.
- `savings_balance`: Savings at the time of the snapshot.

## Application Workflows

1. Choose **Admin Login** or **User Login**.
2. Administrators can manage applicants, import updates, search, sort, delete profiles, and change passwords.
3. Users can view only their own score, eligibility report, financial history, and password controls.
4. Log out to return to the role-selection screen.

### Administrator Dashboard

- **Import Update CSV** imports recognized financial records by email.
- **Refresh List** reloads applicants from SQLite.
- **Add User** creates an applicant and displays the generated initial password.
- **Delete Selected** removes an applicant and linked financial records after confirmation.
- **Search** filters by ID, name, email, or employment status.
- Column headers sort rows; selecting the same header again reverses the order.
- Double-clicking an applicant opens the credit assessment and financial details.

### CSV Import

Update files must contain these headers:

```text
email,record_date,monthly_income,existing_loan_emi,credit_card_utilization,missed_payments_count,employment_tenure_months,savings_balance
```

Rows with unknown email addresses are skipped. Importing a file more than once adds duplicate historical records because each import is treated as a new snapshot.

## Credit Scoring

The score starts at 700 and uses all available records for the applicant:

- Missed payments reduce the score by 60 points each.
- Any missed-payment history prevents an Excellent rating.
- Average utilization above 70% reduces the score; utilization at or below 30% improves it.
- High debt-to-income ratio reduces the score; low debt-to-income improves it.
- Employment tenure and savings provide stability adjustments.
- Scores are bounded between 300 and 850.
- Scores determine the status and maximum qualified loan amount.
- A debt-to-income ratio above 50% makes the applicant ineligible and sets the maximum loan to zero.

## Resetting Generated Data

Close the application, then delete `credit_rating_system/data/` to reset the sample environment. The next run recreates the database, credentials file, and update templates.

The SQLite database is local and unencrypted. Use operating-system file permissions to protect it.
