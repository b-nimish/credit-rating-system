# Credit Rating & Loan Eligibility System

This submission is organized as three files:

```text
credit_rating_system/
├── main.py              # Database access, authentication, scoring, CSV import, and Tkinter UI
├── mock_generation.py   # Database initialization and sample data generation
├── README.md            # This document
└── data/                # Generated runtime data, created automatically
```

The application keeps its runtime data in `credit_rating_system/data/`, alongside these submission files. It creates `credit_rating_system/data/credit_system.db`, `credit_rating_system/data/user_credentials.csv`, and `credit_rating_system/data/updates/` automatically when needed.

## Requirements

- Python 3.8 or newer
- Tkinter, normally included with Python on Windows
- pandas

Install pandas:

```powershell
python -m pip install pandas
```

If `pandas` is already installed, no additional package installation is required. Tkinter is included with most standard Windows Python installations.

## Run

From the `credit_rating_system` project directory:

```powershell
python credit_rating_system\main.py
```

To generate only the database schema and sample data without opening the GUI, run:

```powershell
python credit_rating_system\mock_generation.py
```

The first run creates the SQLite schema, generates 50 sample users and January financial records, creates February and March CSV update templates, and generates user credentials.

Default administrator login:

- Username: `admin`
- Password: `password`

Generated user passwords use the lowercase `namesurname123` format and are written to `credit_rating_system/data/user_credentials.csv`.

The generated update templates are available at `credit_rating_system/data/updates/february_updates.csv` and `credit_rating_system/data/updates/March_updates.csv`.

## Features

- Admin and user login flows
- Admin dashboard with search, sorting, user creation, deletion, and password management
- CSV import for periodic financial records
- Credit score calculation bounded from 300 to 850
- Loan eligibility and maximum loan amount calculation
- User-only eligibility reports and financial history
- SQLite persistence with historical financial records

## Data and Resetting

All generated files are kept inside `credit_rating_system/data/`. To reset the sample environment, close the application and delete `credit_rating_system/data/`. The next run recreates the database, credentials file, and update templates.

The SQLite database is local and unencrypted. Use operating-system file permissions to protect it.
