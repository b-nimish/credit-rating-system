import csv
import random
import sqlite3
from pathlib import Path

PACKAGE_DIR = Path(__file__).resolve().parent
DATA_DIR = PACKAGE_DIR / "data"
DB_PATH = DATA_DIR / "credit_system.db"
UPDATES_DIR = DATA_DIR / "updates"


def get_connection():
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    return sqlite3.connect(DB_PATH)


def init_db():
    with get_connection() as connection:
        connection.executescript(
            """
            CREATE TABLE IF NOT EXISTS users (
                user_id INTEGER PRIMARY KEY AUTOINCREMENT,
                first_name TEXT NOT NULL,
                last_name TEXT NOT NULL,
                email TEXT UNIQUE NOT NULL,
                date_of_birth TEXT NOT NULL,
                employment_status TEXT NOT NULL,
                password_hash TEXT
            );
            CREATE TABLE IF NOT EXISTS admins (
                username TEXT PRIMARY KEY,
                password_hash TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS financial_records (
                record_id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                record_date TEXT NOT NULL,
                monthly_income REAL NOT NULL,
                existing_loan_emi REAL NOT NULL,
                credit_card_utilization REAL NOT NULL,
                missed_payments_count INTEGER NOT NULL,
                employment_tenure_months INTEGER NOT NULL DEFAULT 0,
                savings_balance REAL NOT NULL DEFAULT 0,
                FOREIGN KEY (user_id) REFERENCES users (user_id)
            );
            """
        )
        user_columns = {row[1] for row in connection.execute("PRAGMA table_info(users)")}
        if "password_hash" not in user_columns:
            connection.execute("ALTER TABLE users ADD COLUMN password_hash TEXT")
        record_columns = {row[1] for row in connection.execute("PRAGMA table_info(financial_records)")}
        if "employment_tenure_months" not in record_columns:
            connection.execute(
                "ALTER TABLE financial_records ADD COLUMN employment_tenure_months INTEGER NOT NULL DEFAULT 0"
            )
        if "savings_balance" not in record_columns:
            connection.execute(
                "ALTER TABLE financial_records ADD COLUMN savings_balance REAL NOT NULL DEFAULT 0"
            )


def generate_mock_data():
    init_db()
    with get_connection() as connection:
        if connection.execute("SELECT COUNT(*) FROM users").fetchone()[0] > 0:
            return "Database already initialized with data."

        first_names = [
            "Arjun", "Neha", "Rohan", "Priya", "Amit", "Sneha", "Vikram", "Ananya", "Rahul", "Pooja",
            "Karan", "Isha", "Manav", "Divya", "Sahil", "Nisha", "Aditya", "Sakshi", "Nitin", "Meera",
            "Harsh", "Tanvi", "Yash", "Mitali", "Rajat", "Kavya", "Om", "Ritika", "Vipul", "Aisha",
            "Dev", "Shreya", "Parth", "Komal", "Tushar", "Esha", "Gaurav", "Heena", "Jay", "Riya",
            "Abhishek", "Jiya", "Sameer", "Anjali", "Varun", "Pallavi", "Nikhil", "Swati", "Deepak", "Ankita",
        ]
        last_names = [
            "Sharma", "Verma", "Kumar", "Patel", "Singh", "Joshi", "Das", "Mehta", "Reddy", "Nair",
            "Mishra", "Gupta", "Iyer", "Bose", "Saxena", "Kapoor", "Kulkarni", "Naik", "Roy", "Sen",
            "Chopra", "Agarwal", "Malhotra", "Jain", "Balakrishnan", "Yadav", "Rao", "Banerjee", "Dutta", "Sethi",
            "Bhatia", "Desai", "Pillai", "Murthy", "Khanna", "Bharadwaj", "Nadkarni", "Khan", "Sengupta", "Vora",
            "Chatterjee", "Prasad", "Tripathi", "Lal", "Pandey", "Mayekar", "Soni", "Bhardwaj", "Chauhan", "Shah",
        ]
        statuses = ["Employed", "Self-Employed", "Unemployed"]
        users_data = []
        for index in range(50):
            first_name = first_names[index]
            last_name = last_names[index]
            users_data.append(
                (
                    first_name,
                    last_name,
                    f"{first_name.lower()}.{last_name.lower()}@example.com",
                    f"19{random.randint(75, 99)}-{random.randint(1, 12):02d}-{random.randint(1, 28):02d}",
                    random.choice(statuses),
                )
            )
        connection.executemany(
            "INSERT INTO users (first_name, last_name, email, date_of_birth, employment_status) VALUES (?, ?, ?, ?, ?)",
            users_data,
        )

        users = connection.execute("SELECT user_id, email FROM users").fetchall()
        january_tenures = {}
        for user_id, email in users:
            values = (
                random.randint(40000, 150000),
                random.choice([0, 0, 5000, 12000, 25000]),
                round(random.uniform(0.05, 0.85), 2),
                random.choice([0, 0, 0, 0, 1]),
                random.randint(3, 120),
                random.randint(10000, 750000),
            )
            january_tenures[email] = values[4]
            connection.execute(
                """INSERT INTO financial_records (
                    user_id, record_date, monthly_income, existing_loan_emi,
                    credit_card_utilization, missed_payments_count,
                    employment_tenure_months, savings_balance
                ) VALUES (?, '2026-01-15', ?, ?, ?, ?, ?, ?)""",
                (user_id, *values),
            )

    UPDATES_DIR.mkdir(parents=True, exist_ok=True)
    headers = [
        "email", "record_date", "monthly_income", "existing_loan_emi",
        "credit_card_utilization", "missed_payments_count",
        "employment_tenure_months", "savings_balance",
    ]
    for filename, date, tenure_offset in (
        ("february_updates.csv", "2026-02-15", 1),
        ("March_updates.csv", "2026-03-15", 2),
    ):
        with (UPDATES_DIR / filename).open("w", newline="", encoding="utf-8") as update_file:
            writer = csv.writer(update_file)
            writer.writerow(headers)
            for _, email in users:
                writer.writerow(
                    [
                        email,
                        date,
                        random.randint(40000, 150000),
                        random.choice([0, 0, 5000, 12000, 25000]),
                        round(random.uniform(0.05, 0.85), 2),
                        random.choice([0, 0, 0, 0, 2]),
                        january_tenures[email] + tenure_offset,
                        random.randint(10000, 750000),
                    ]
                )
    return f"Sample database built. Mock CSV templates created in: {UPDATES_DIR}"


if __name__ == "__main__":
    print(generate_mock_data())
