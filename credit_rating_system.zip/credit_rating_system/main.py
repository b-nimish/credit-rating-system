"""Credit rating application entry point.

This module contains the SQLite access helpers, password authentication,
credit-score calculation, CSV importing, and Tkinter user interface for the
three-file deployment. Run it directly to initialize the local database and
open the login window.
"""

import hashlib
import hmac
import sqlite3
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

import pandas as pd

from mock_generation import generate_mock_data, get_connection, init_db

DEFAULT_USERNAME = "admin"
_PASSWORD_SALT = b"credit-rating-system-login"
_USER_PASSWORD_SALT = b"credit-rating-system-user-login"


def authenticate_admin(username, password):
    """Return whether an administrator's credentials are valid."""
    password_hash = hashlib.pbkdf2_hmac("sha256", password.encode(), _PASSWORD_SALT, 200_000)
    with get_connection() as connection:
        row = connection.execute(
            "SELECT password_hash FROM admins WHERE username = ?", (username,)
        ).fetchone()
    return row is not None and hmac.compare_digest(password_hash.hex(), row[0])


def ensure_admin_account():
    """Create the default administrator account when it does not exist."""
    with get_connection() as connection:
        row = connection.execute(
            "SELECT username FROM admins WHERE username = ?", (DEFAULT_USERNAME,)
        ).fetchone()
        if row is None:
            password_hash = hashlib.pbkdf2_hmac(
                "sha256", b"password", _PASSWORD_SALT, 200_000
            ).hex()
            connection.execute(
                "INSERT INTO admins (username, password_hash) VALUES (?, ?)",
                (DEFAULT_USERNAME, password_hash),
            )


def change_admin_password(username, current_password, new_password):
    """Replace an administrator password after verifying the old password."""
    if not authenticate_admin(username, current_password) or not new_password:
        return False
    password_hash = hashlib.pbkdf2_hmac(
        "sha256", new_password.encode(), _PASSWORD_SALT, 200_000
    ).hex()
    with get_connection() as connection:
        connection.execute(
            "UPDATE admins SET password_hash = ? WHERE username = ?",
            (password_hash, username),
        )
    return True


def hash_user_password(password):
    """Return the PBKDF2 hash used for user passwords."""
    return hashlib.pbkdf2_hmac(
        "sha256", password.encode(), _USER_PASSWORD_SALT, 200_000
    ).hex()


def generate_user_password(first_name, last_name):
    """Build the initial password assigned to a newly created user."""
    return f"{first_name}{last_name}123".replace(" ", "").lower()


def authenticate_user(email, password):
    """Authenticate a user by email and return a session-ready user record."""
    normalized_email = email.strip().lower()
    with get_connection() as connection:
        row = connection.execute(
            "SELECT user_id, first_name, last_name, password_hash FROM users WHERE email = ?",
            (normalized_email,),
        ).fetchone()
    if row is None or row[3] is None:
        return None
    if not hmac.compare_digest(hash_user_password(password), row[3]):
        return None
    return {
        "user_id": row[0],
        "first_name": row[1],
        "last_name": row[2],
        "email": normalized_email,
    }


def change_user_password(user_id, current_password, new_password):
    """Change a user's password after checking the current password."""
    if not new_password:
        return False
    with get_connection() as connection:
        row = connection.execute(
            "SELECT password_hash FROM users WHERE user_id = ?", (user_id,)
        ).fetchone()
        if row is None or not hmac.compare_digest(hash_user_password(current_password), row[0]):
            return False
        connection.execute(
            "UPDATE users SET password_hash = ? WHERE user_id = ?",
            (hash_user_password(new_password), user_id),
        )
    return True


def set_user_password(user_id, new_password):
    """Set a user's password directly for an administrator reset."""
    if not new_password:
        return False
    with get_connection() as connection:
        cursor = connection.execute(
            "UPDATE users SET password_hash = ? WHERE user_id = ?",
            (hash_user_password(new_password), user_id),
        )
    return cursor.rowcount == 1


def ensure_user_passwords():
    """Hash missing user passwords and append generated credentials to CSV."""
    generated = []
    with get_connection() as connection:
        rows = connection.execute(
            "SELECT user_id, first_name, last_name, email FROM users WHERE password_hash IS NULL"
        ).fetchall()
        for user_id, first_name, last_name, email in rows:
            password = generate_user_password(first_name, last_name)
            connection.execute(
                "UPDATE users SET password_hash = ? WHERE user_id = ?",
                (hash_user_password(password), user_id),
            )
            generated.append((email, password))
    if generated:
        credentials_path = Path(__file__).resolve().parent / "data" / "user_credentials.csv"
        credentials_path.parent.mkdir(parents=True, exist_ok=True)
        with credentials_path.open("a", encoding="utf-8", newline="") as credentials_file:
            if credentials_file.tell() == 0:
                credentials_file.write("email,password\n")
            for email, password in generated:
                credentials_file.write(f"{email},{password}\n")
    return generated


def calculate_credit_score(user_id):
    """Calculate score, eligibility status, and maximum loan for a user.

    All available financial records contribute to the score. Missed payments
    reduce the score, utilization and debt-to-income ratios affect risk, and
    the result is bounded to the 300-850 credit-score range.
    """
    with get_connection() as connection:
        records = connection.execute(
            """SELECT monthly_income, existing_loan_emi, credit_card_utilization,
                missed_payments_count, employment_tenure_months, savings_balance
                FROM financial_records WHERE user_id = ? ORDER BY record_date DESC""",
            (user_id,),
        ).fetchall()
    if not records:
        return 500, "No History", 0.0

    latest_income, latest_emi, _, _, latest_tenure, latest_savings = records[0]
    total_missed_payments = sum(record[3] for record in records)
    score = 700 - total_missed_payments * 60
    avg_utilization = sum(record[2] for record in records) / len(records)
    if avg_utilization > 0.70:
        score -= 50
    elif avg_utilization <= 0.30:
        score += 50

    dti = latest_emi / latest_income if latest_income > 0 else 1.0
    if dti > 0.45:
        score -= 60
    elif dti < 0.20:
        score += 40
    if latest_tenure >= 60:
        score += 30
    elif latest_tenure >= 24:
        score += 20
    elif latest_tenure >= 12:
        score += 10
    elif latest_tenure < 6:
        score -= 15

    savings_months = latest_savings / latest_income if latest_income > 0 else 0
    if savings_months >= 6:
        score += 30
    elif savings_months >= 3:
        score += 20
    elif savings_months >= 1:
        score += 10
    elif latest_savings <= 0:
        score -= 10

    # A missed payment must prevent an otherwise positive profile from being rated Excellent.
    if total_missed_payments > 0:
        score = min(score, 749)

    score = max(300, min(850, score))
    if score >= 750:
        status, max_loan = "Excellent (Highly Eligible)", latest_income * 12
    elif score >= 650:
        status, max_loan = "Good (Eligible with Standard Rates)", latest_income * 6
    elif score >= 550:
        status, max_loan = "Fair (High Risk/Conditional)", latest_income * 2
    else:
        status, max_loan = "Poor (Ineligible)", 0.0
    if dti > 0.50:
        status, max_loan = "Ineligible (Debt Load Too High)", 0.0
    return score, status, round(max_loan, 2)


def import_csv_update(csv_file_path):
    """Validate and import recognized financial records from a CSV file.

    Returns ``(success, message)`` and skips rows whose email is not in the
    local users table.
    """
    if not Path(csv_file_path).exists():
        return False, "File not found."
    try:
        frame = pd.read_csv(csv_file_path)
        required = [
            "email", "record_date", "monthly_income", "existing_loan_emi",
            "credit_card_utilization", "missed_payments_count",
            "employment_tenure_months", "savings_balance",
        ]
        if not all(column in frame.columns for column in required):
            return False, f"CSV must contain headers: {', '.join(required)}"
        added = skipped = 0
        with get_connection() as connection:
            for _, row in frame.iterrows():
                user = connection.execute(
                    "SELECT user_id FROM users WHERE email = ?", (row["email"],)
                ).fetchone()
                if user is None:
                    skipped += 1
                    continue
                connection.execute(
                    """INSERT INTO financial_records (
                        user_id, record_date, monthly_income, existing_loan_emi,
                        credit_card_utilization, missed_payments_count,
                        employment_tenure_months, savings_balance
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                    (user[0], row["record_date"], row["monthly_income"], row["existing_loan_emi"],
                     row["credit_card_utilization"], row["missed_payments_count"],
                     row["employment_tenure_months"], row["savings_balance"]),
                )
                added += 1
        return True, f"Successfully parsed. Added {added} updates. Skipped {skipped} unrecognized emails."
    except Exception as error:
        return False, str(error)


def clear_window(root):
    """Remove all child widgets before switching application views."""
    for widget in root.winfo_children():
        widget.destroy()


def create_login_window(root, on_admin_success, on_user_success):
    """Display the role-selection screen for administrator or user login."""
    clear_window(root)
    root.title("Credit Rating System - Login")
    root.geometry("420x300")
    root.resizable(False, False)
    frame = ttk.Frame(root, padding=30)
    frame.pack(expand=True, fill="both")
    ttk.Label(frame, text="Choose login type", font=("Arial", 16, "bold")).pack(pady=(0, 22))
    ttk.Button(frame, text="Admin Login", command=lambda: show_login_form(
        root, "Admin Login", "Username", DEFAULT_USERNAME, on_admin_success, False,
        on_admin_success, on_user_success,
    )).pack(fill="x", pady=6)
    ttk.Button(frame, text="User Login", command=lambda: show_login_form(
        root, "User Login", "Email", "", on_user_success, True,
        on_admin_success, on_user_success,
    )).pack(fill="x", pady=6)


def show_login_form(root, title, identity_label, default_identity, on_success, is_user,
                    on_admin_success, on_user_success):
    """Build a login form for either administrator or user credentials."""
    clear_window(root)
    root.title(f"Credit Rating System - {title}")
    frame = ttk.Frame(root, padding=30)
    frame.pack(expand=True, fill="both")
    ttk.Label(frame, text=title, font=("Arial", 16, "bold")).pack(pady=(0, 18))
    ttk.Label(frame, text=identity_label).pack(anchor="w")
    identity_entry = ttk.Entry(frame)
    identity_entry.pack(fill="x", pady=(2, 10))
    identity_entry.insert(0, default_identity)
    ttk.Label(frame, text="Password").pack(anchor="w")
    password_entry = ttk.Entry(frame, show="*")
    password_entry.pack(fill="x", pady=(2, 12))
    status_label = ttk.Label(frame, text="")
    status_label.pack()
    submit = lambda: login(root, identity_entry, password_entry, status_label, on_success, is_user)
    ttk.Button(frame, text="Log in", command=submit).pack(pady=6)
    ttk.Button(frame, text="Back", command=lambda: create_login_window(
        root, on_admin_success, on_user_success
    )).pack()
    password_entry.bind("<Return>", lambda event: submit())
    identity_entry.focus_set()


def login(root, identity_entry, password_entry, status_label, on_success, is_user):
    """Validate login fields and call the appropriate success callback."""
    identity = identity_entry.get().strip()
    password = password_entry.get()
    result = authenticate_user(identity, password) if is_user else authenticate_admin(identity, password)
    if result:
        on_success(result) if is_user else on_success()
        return
    status_label.configure(text="Invalid username or password")
    password_entry.delete(0, tk.END)
    password_entry.focus_set()


def create_user_view(root, user, on_logout):
    """Display a user's score, eligibility, details, and account actions."""
    root.title("My Loan Eligibility")
    root.geometry("520x440")
    root.resizable(False, False)
    frame = ttk.Frame(root, padding=24)
    frame.pack(expand=True, fill="both")
    score, status, max_loan = calculate_credit_score(user["user_id"])
    full_name = f"{user['first_name']} {user['last_name']}"
    ttk.Label(frame, text="Loan Eligibility", font=("Arial", 18, "bold")).pack(pady=(0, 18))
    ttk.Label(frame, text=f"Applicant: {full_name}", font=("Arial", 11)).pack(pady=5)
    ttk.Label(frame, text=f"Email: {user['email']}").pack(pady=5)
    ttk.Label(frame, text=f"Credit Score: {score} / 850", font=("Arial", 14, "bold"),
              foreground="green" if score >= 650 else "red").pack(pady=10)
    ttk.Label(frame, text=f"Eligibility Status: {status}", font=("Arial", 11)).pack(pady=5)
    ttk.Label(frame, text=f"Maximum Qualified Loan Amount: Rs.{max_loan:,}",
              font=("Arial", 12, "bold"), foreground="navy").pack(pady=10)
    ttk.Button(frame, text="View Details", command=lambda: show_financial_details(
        root, user["user_id"], full_name
    )).pack(pady=5)
    ttk.Button(frame, text="Change Password", command=lambda: change_user_password_dialog(
        root, user
    )).pack(pady=(8, 4))
    ttk.Button(frame, text="Log out", command=on_logout).pack(pady=4)


def create_dashboard(root, on_logout):
    """Build the administrator dashboard and load its applicant table."""
    state = {"root": root, "all_rows": [], "sort_column": None, "sort_reverse": False,
             "on_logout": on_logout}
    root.title("Credit Rating & Loan Eligibility System")
    root.geometry("850x550")
    root.columnconfigure(0, weight=1)
    root.rowconfigure(1, weight=1)
    create_top_panel(state)
    create_main_table(state)
    refresh_table(state)
    return state


def create_top_panel(state):
    """Create dashboard controls for data, accounts, search, and logout."""
    root = state["root"]
    top_frame = ttk.Frame(root, padding=10)
    top_frame.grid(row=0, column=0, sticky="ew")
    top_frame.columnconfigure(0, weight=1)
    data_actions = ttk.LabelFrame(top_frame, text="Data Management", padding=6)
    data_actions.grid(row=0, column=0, sticky="ew", pady=(0, 6))
    for column in range(4):
        data_actions.columnconfigure(column, weight=1)
    for column, (label, command) in enumerate((
        ("Import Update CSV", lambda: upload_csv(state)), ("Refresh List", lambda: refresh_table(state)),
        ("Add User", lambda: add_user(state)), ("Delete Selected", lambda: delete_selected(state)),
    )):
        ttk.Button(data_actions, text=label, command=command).grid(row=0, column=column, sticky="ew", padx=4, pady=2)
    account_actions = ttk.LabelFrame(top_frame, text="Account Management", padding=6)
    account_actions.grid(row=1, column=0, sticky="ew", pady=(0, 6))
    for column in range(3):
        account_actions.columnconfigure(column, weight=1)
    for column, (label, command) in enumerate((
        ("Change Admin Password", lambda: change_admin_password_dialog(root)),
        ("Change User Password", lambda: change_selected_user_password(state)),
        ("Log out", state["on_logout"]),
    )):
        ttk.Button(account_actions, text=label, command=command).grid(row=0, column=column, sticky="ew", padx=4, pady=2)
    search_frame = ttk.Frame(top_frame)
    search_frame.grid(row=2, column=0, sticky="ew", pady=(0, 4))
    search_frame.columnconfigure(1, weight=1)
    ttk.Label(search_frame, text="Search:").grid(row=0, column=0, padx=(0, 6))
    state["search_var"] = tk.StringVar()
    state["search_entry"] = ttk.Entry(search_frame, textvariable=state["search_var"])
    state["search_entry"].grid(row=0, column=1, sticky="ew", padx=4)
    state["search_var"].trace_add("write", lambda *_: display_rows(state))
    ttk.Button(search_frame, text="Clear", command=lambda: clear_search(state)).grid(row=0, column=2, padx=(4, 0))


def create_main_table(state):
    """Create the sortable applicant table and double-click binding."""
    table_frame = ttk.Frame(state["root"], padding=10)
    table_frame.grid(row=1, column=0, sticky="nsew")
    table_frame.columnconfigure(0, weight=1)
    table_frame.rowconfigure(0, weight=1)
    columns = ("id", "first_name", "last_name", "email", "employment")
    tree = ttk.Treeview(table_frame, columns=columns, show="headings")
    state["tree"] = tree
    headings = {"id": "ID", "first_name": "First Name", "last_name": "Last Name", "email": "Email ID", "employment": "Employment Status"}
    for column, heading in headings.items():
        tree.heading(column, text=heading, command=lambda selected=column: sort_rows(state, selected))
    for column, width in (("id", 50), ("first_name", 120), ("last_name", 120), ("email", 250), ("employment", 150)):
        tree.column(column, width=width, anchor="center" if column == "id" else "w")
    scrollbar = ttk.Scrollbar(table_frame, orient="vertical", command=tree.yview)
    tree.configure(yscrollcommand=scrollbar.set)
    tree.grid(row=0, column=0, sticky="nsew")
    scrollbar.grid(row=0, column=1, sticky="ns")
    tree.bind("<Double-1>", lambda event: on_row_double_click(event, state))


def refresh_table(state):
    """Reload users from SQLite and refresh the visible dashboard rows."""
    try:
        with get_connection() as connection:
            state["all_rows"] = connection.execute(
                "SELECT user_id, first_name, last_name, email, employment_status FROM users"
            ).fetchall()
        display_rows(state)
    except Exception as error:
        messagebox.showerror("Error", f"Could not load users: {error}")


def display_rows(state):
    """Apply the current search and sort settings to the applicant table."""
    search_text = state["search_var"].get().strip().casefold()
    rows = state["all_rows"]
    if search_text:
        rows = [row for row in rows if search_text in " ".join(map(str, row)).casefold()]
    column = state["sort_column"]
    if column is not None:
        index = state["tree"]["columns"].index(column)
        rows = sorted(rows, key=lambda row: int(row[index]) if column == "id" else str(row[index]).casefold(), reverse=state["sort_reverse"])
    for item in state["tree"].get_children():
        state["tree"].delete(item)
    for row in rows:
        state["tree"].insert("", "end", values=row)


def sort_rows(state, column):
    """Toggle sorting for a selected table column and redraw the rows."""
    state["sort_reverse"] = not state["sort_reverse"] if state["sort_column"] == column else False
    state["sort_column"] = column
    display_rows(state)


def clear_search(state):
    """Clear the dashboard search field and restore keyboard focus."""
    state["search_var"].set("")
    state["search_entry"].focus_set()


def selected_user(state):
    """Return the selected table row values, or ``None`` if no row is selected."""
    selected = state["tree"].selection()
    return state["tree"].item(selected[0], "values") if selected else None


def delete_selected(state):
    """Delete the selected user and all linked financial records."""
    values = selected_user(state)
    if not values:
        messagebox.showwarning("No Selection", "Select an applicant before deleting.")
        return
    full_name = f"{values[1]} {values[2]}"
    if not messagebox.askyesno("Confirm Deletion", f"Delete {full_name} and all of their financial records?\n\nThis action cannot be undone."):
        return
    try:
        with get_connection() as connection:
            connection.execute("DELETE FROM financial_records WHERE user_id = ?", (values[0],))
            connection.execute("DELETE FROM users WHERE user_id = ?", (values[0],))
        messagebox.showinfo("Deleted", f"{full_name} was deleted.")
        refresh_table(state)
    except Exception as error:
        messagebox.showerror("Delete Failed", f"Could not delete {full_name}: {error}")


def add_user(state):
    """Open the form used to create a new applicant profile."""
    dialog = tk.Toplevel(state["root"])
    dialog.title("Add New User")
    dialog.geometry("380x300")
    dialog.transient(state["root"])
    dialog.grab_set()
    fields = (("First Name", "first_name"), ("Last Name", "last_name"), ("Email", "email"), ("Date of Birth", "date_of_birth"), ("Employment Status", "employment_status"))
    entries = {}
    form = ttk.Frame(dialog, padding=20)
    form.pack(fill="both", expand=True)
    for row, (label, name) in enumerate(fields):
        ttk.Label(form, text=label).grid(row=row, column=0, sticky="w", padx=(0, 10), pady=5)
        entries[name] = ttk.Entry(form, width=30)
        entries[name].grid(row=row, column=1, sticky="ew", pady=5)
    form.columnconfigure(1, weight=1)
    ttk.Button(form, text="Save User", command=lambda: save_user(dialog, entries, state)).grid(row=len(fields), column=1, sticky="e", pady=15)
    entries["first_name"].focus_set()


def save_user(dialog, entries, state):
    """Validate and persist a new user entered through the dashboard form."""
    values = {name: entry.get().strip() for name, entry in entries.items()}
    if any(not value for value in values.values()):
        messagebox.showwarning("Incomplete Details", "Please complete every field.", parent=dialog)
        return
    password = generate_user_password(values["first_name"], values["last_name"])
    try:
        with get_connection() as connection:
            connection.execute(
                "INSERT INTO users (first_name, last_name, email, date_of_birth, employment_status, password_hash) VALUES (?, ?, ?, ?, ?, ?)",
                (values["first_name"], values["last_name"], values["email"].lower(), values["date_of_birth"], values["employment_status"], hash_user_password(password)),
            )
    except sqlite3.IntegrityError:
        messagebox.showerror("Could Not Add User", "That email address already exists.", parent=dialog)
        return
    except Exception as error:
        messagebox.showerror("Could Not Add User", str(error), parent=dialog)
        return
    dialog.destroy()
    refresh_table(state)
    messagebox.showinfo("User Added", f"The new user was added successfully.\n\nUser email: {values['email'].lower()}\nInitial password: {password}", parent=state["root"])


def upload_csv(state):
    """Open a CSV picker and import the selected financial update file."""
    file_path = filedialog.askopenfilename(filetypes=[("CSV Files", "*.csv")])
    if not file_path:
        return
    success, message = import_csv_update(file_path)
    (messagebox.showinfo if success else messagebox.showerror)("Success" if success else "Import Failed", message)
    if success:
        refresh_table(state)


def on_row_double_click(event, state):
    """Open the score assessment for the applicant in the clicked row."""
    values = selected_user(state)
    if not values:
        return
    user_id, full_name = values[0], f"{values[1]} {values[2]}"
    score, status, max_loan = calculate_credit_score(user_id)
    pop = tk.Toplevel(state["root"])
    pop.title(f"Credit Score Assessment: {full_name}")
    pop.geometry("520x380")
    ttk.Label(pop, text="Assessment Report", font=("Arial", 14, "bold")).pack(pady=15)
    ttk.Label(pop, text=f"Applicant: {full_name}").pack(pady=5)
    ttk.Label(pop, text=f"Credit Score: {score} / 850", font=("Arial", 12, "bold"), foreground="green" if score >= 650 else "red").pack(pady=8)
    ttk.Label(pop, text=f"Eligibility Status: {status}").pack(pady=5)
    ttk.Label(pop, text=f"Maximum Qualified Loan Amount: Rs.{max_loan:,}", font=("Arial", 11, "bold"), foreground="navy").pack(pady=10)
    ttk.Button(pop, text="View Details", command=lambda: show_financial_details(pop, user_id, full_name)).pack(pady=5)
    ttk.Button(pop, text="Close", command=pop.destroy).pack(pady=15)


def show_financial_details(parent, user_id, full_name):
    """Display the selected user's chronological financial records."""
    details = tk.Toplevel(parent)
    details.title(f"Financial Details: {full_name}")
    details.geometry("1120x320")
    frame = ttk.Frame(details, padding=12)
    frame.pack(fill="both", expand=True)
    columns = ("record_date", "monthly_income", "existing_loan_emi", "credit_card_utilization", "missed_payments_count", "employment_tenure_months", "savings_balance")
    headings = ("Record Date", "Monthly Income", "Existing Loan EMI", "Credit Card Utilization", "Missed Payments", "Employment Tenure (Months)", "Savings Balance")
    tree = ttk.Treeview(frame, columns=columns, show="headings")
    for column, heading in zip(columns, headings):
        tree.heading(column, text=heading)
        tree.column(column, width=135, anchor="center")
    tree.grid(row=0, column=0, sticky="nsew")
    scrollbar = ttk.Scrollbar(frame, orient="vertical", command=tree.yview)
    scrollbar.grid(row=0, column=1, sticky="ns")
    tree.configure(yscrollcommand=scrollbar.set)
    frame.columnconfigure(0, weight=1)
    frame.rowconfigure(0, weight=1)
    with get_connection() as connection:
        records = connection.execute(
            "SELECT record_date, monthly_income, existing_loan_emi, credit_card_utilization, missed_payments_count, employment_tenure_months, savings_balance FROM financial_records WHERE user_id = ? ORDER BY record_date DESC",
            (user_id,),
        ).fetchall()
    for record in records:
        tree.insert("", "end", values=record)
    if not records:
        ttk.Label(details, text="No financial records available.").pack(pady=8)
    ttk.Button(details, text="Close", command=details.destroy).pack(pady=10)


def password_dialog(root, title, submit_callback):
    """Build the shared current/new password form used by account dialogs."""
    dialog = tk.Toplevel(root)
    dialog.title(title)
    dialog.geometry("380x250")
    dialog.transient(root)
    dialog.grab_set()
    form = ttk.Frame(dialog, padding=20)
    form.pack(fill="both", expand=True)
    fields = {}
    for row, (label, name) in enumerate((("Current Password", "current"), ("New Password", "new"), ("Confirm New Password", "confirm"))):
        ttk.Label(form, text=label).grid(row=row, column=0, sticky="w", pady=5)
        fields[name] = ttk.Entry(form, show="*", width=25)
        fields[name].grid(row=row, column=1, sticky="ew", pady=5)
    form.columnconfigure(1, weight=1)
    ttk.Button(form, text="Save Password", command=lambda: submit_callback(dialog, fields)).grid(row=3, column=1, sticky="e", pady=12)
    fields["current"].focus_set()


def change_user_password_dialog(root, user):
    """Open the user self-service password-change dialog."""
    def submit(dialog, fields):
        """Validate and apply the user's requested password change."""
        if fields["new"].get() != fields["confirm"].get():
            messagebox.showerror("Password Error", "The new passwords do not match.", parent=dialog)
        elif change_user_password(user["user_id"], fields["current"].get(), fields["new"].get()):
            dialog.destroy()
            messagebox.showinfo("Password Changed", "Your password was changed successfully.", parent=root)
        else:
            messagebox.showerror("Password Error", "The current password is incorrect.", parent=dialog)
    password_dialog(root, "Change Password", submit)


def change_selected_user_password(state):
    """Open the administrator dialog for resetting a selected user's password."""
    values = selected_user(state)
    if not values:
        messagebox.showwarning("No Selection", "Select an applicant before changing their password.")
        return
    dialog = tk.Toplevel(state["root"])
    dialog.title("Change User Password")
    dialog.geometry("420x200")
    form = ttk.Frame(dialog, padding=20)
    form.pack(fill="both", expand=True)
    ttk.Label(form, text=f"User: {values[1]} {values[2]}").pack(anchor="w", pady=3)
    password_entry = ttk.Entry(form, show="*", width=32)
    password_entry.pack(fill="x", pady=8)
    def save():
        """Save the administrator-selected user's replacement password."""
        if set_user_password(values[0], password_entry.get()):
            dialog.destroy()
            messagebox.showinfo("Password Changed", f"The password for {values[1]} {values[2]} was changed.", parent=state["root"])
        else:
            messagebox.showerror("Password Error", "Password cannot be empty.", parent=dialog)
    ttk.Button(form, text="Save Password", command=save).pack(anchor="e")
    password_entry.focus_set()


def change_admin_password_dialog(root):
    """Open the administrator self-service password-change dialog."""
    def submit(dialog, fields):
        """Validate and apply the administrator's requested password change."""
        if fields["new"].get() != fields["confirm"].get():
            messagebox.showerror("Password Error", "The new passwords do not match.", parent=dialog)
        elif change_admin_password(DEFAULT_USERNAME, fields["current"].get(), fields["new"].get()):
            dialog.destroy()
            messagebox.showinfo("Password Changed", "The admin password was changed successfully.", parent=root)
        else:
            messagebox.showerror("Password Error", "The current password is incorrect.", parent=dialog)
    password_dialog(root, "Change Admin Password", submit)


def main():
    """Initialize the application and start the Tkinter event loop."""
    root = tk.Tk()
    root.protocol("WM_DELETE_WINDOW", root.quit)
    init_db()
    ensure_admin_account()
    generate_mock_data()
    credentials = ensure_user_passwords()
    if credentials:
        print("Generated initial user passwords in data/user_credentials.csv")

    def show_login():
        """Return the root window to the role-selection screen."""
        create_login_window(root, open_admin_dashboard, open_user_report)

    def open_admin_dashboard():
        """Replace the login view with the administrator dashboard."""
        clear_window(root)
        create_dashboard(root, show_login)

    def open_user_report(user):
        """Replace the login view with the authenticated user's report."""
        clear_window(root)
        create_user_view(root, user, show_login)

    create_login_window(root, open_admin_dashboard, open_user_report)
    root.mainloop()
    root.destroy()


if __name__ == "__main__":
    main()
